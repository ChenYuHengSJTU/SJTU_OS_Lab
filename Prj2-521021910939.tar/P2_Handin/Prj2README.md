# Files submitted

### Source code file:

+ LarryCurlyMoe.c
+ Faneuil.c

### Test file:

+ test-Faneuil.py
+ test-LCM.py

### Demo file:

+ show.ipynb
+ show.html
+ show.pdf
### Other file:

+ Lab2-Report
+ Prj2README.md
+ Makefile
